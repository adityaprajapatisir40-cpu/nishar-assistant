package com.aditya.nishar

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application root. @HiltAndroidApp generates the top-level DI container that
 * every ViewModel, Service, and Worker in the app will pull dependencies from
 * (Room database, Retrofit/Gemini client, repositories) as later slices add them.
 */
@HiltAndroidApp
class NisharApplication : Application()
