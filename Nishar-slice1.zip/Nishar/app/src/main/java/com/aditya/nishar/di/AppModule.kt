package com.aditya.nishar.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Root Hilt module. Deliberately empty in slice 1 — it exists now so the
 * Hilt Gradle plugin has a real module to process and the DI graph compiles
 * end-to-end. @Provides functions for the Room database, Retrofit/Gemini
 * client, and repositories are added here module-by-module as each slice
 * introduces them, rather than declaring them now with fake implementations.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule
