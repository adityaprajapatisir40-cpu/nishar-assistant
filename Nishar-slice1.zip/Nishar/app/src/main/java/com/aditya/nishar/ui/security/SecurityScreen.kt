package com.aditya.nishar.ui.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.nishar.ui.theme.NisharGold

/**
 * NOTE (slice 1 honesty marker): this screen is intentionally a placeholder.
 * Owner face enrollment, ML Kit face detection, intruder capture, and the
 * PIN-fail dashboard are built in the Security slice (roadmap step 6), which
 * needs CameraX + ML Kit wiring and runtime permission flows that don't exist
 * yet. Nothing here pretends those features are implemented — the route and
 * screen exist so navigation and the Home dashboard button have somewhere
 * real to go today.
 */
@Composable
fun SecurityScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Security", color = NisharGold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = NisharGold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Shield,
                contentDescription = null,
                tint = NisharGold.copy(alpha = 0.5f),
                modifier = Modifier
            )
            Text(
                text = "Face security, intruder detection, and the security " +
                    "dashboard arrive in the next build slice.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
        }
    }
}
