package com.aditya.nishar.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.nishar.ui.theme.NisharGold

/**
 * Settings shell for slice 1. Each toggle here is real UI state today; the
 * *persistence* of these choices (DataStore/Room) and the *effects* they
 * trigger (actually switching TTS voice, actually forcing light theme) are
 * wired in the AI and Security slices once those subsystems exist. Keeping
 * the state local for now is intentional — it's not a fake control, it's a
 * real control waiting for its backing store.
 */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var darkModeEnabled by remember { mutableStateOf(true) }
    var wakeWordEnabled by remember { mutableStateOf(true) }
    var voiceRepliesEnabled by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = NisharGold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = NisharGold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 16.dp)) {

            SettingsToggleRow(
                label = "Dark Mode (Black + Gold)",
                checked = darkModeEnabled,
                onCheckedChange = { darkModeEnabled = it }
            )
            HorizontalDivider()
            SettingsToggleRow(
                label = "Wake Word (\"Nishar\")",
                checked = wakeWordEnabled,
                onCheckedChange = { wakeWordEnabled = it }
            )
            HorizontalDivider()
            SettingsToggleRow(
                label = "Speak Every Reply",
                checked = voiceRepliesEnabled,
                onCheckedChange = { voiceRepliesEnabled = it }
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun SettingsToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = NisharGold)
        )
    }
}
