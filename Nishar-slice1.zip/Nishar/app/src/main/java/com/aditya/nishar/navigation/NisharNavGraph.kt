package com.aditya.nishar.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aditya.nishar.ui.home.HomeScreen
import com.aditya.nishar.ui.security.SecurityScreen
import com.aditya.nishar.ui.settings.SettingsScreen
import com.aditya.nishar.ui.splash.SplashScreen

@Composable
fun NisharNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Screen.Splash.route) {

        composable(Screen.Splash.route) {
            SplashScreen(
                onFinished = {
                    navController.navigate(Screen.Home.route) {
                        // Splash is a one-time animation, never a back-stack entry.
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onOpenSettings = { navController.navigate(Screen.Settings.route) },
                onOpenSecurity = { navController.navigate(Screen.Security.route) }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Security.route) {
            SecurityScreen(onBack = { navController.popBackStack() })
        }
    }
}
