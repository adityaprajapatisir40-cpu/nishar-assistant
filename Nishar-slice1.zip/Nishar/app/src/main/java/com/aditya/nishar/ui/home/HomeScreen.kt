package com.aditya.nishar.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aditya.nishar.ui.theme.NisharGold
import com.aditya.nishar.ui.theme.NisharSurface

/** One feature tile on the Home dashboard grid. Wiring (onClick actions) is
 *  added feature-by-feature as each capability slice lands; the layout itself
 *  doesn't change. */
private data class DashboardCard(val title: String, val subtitle: String)

private val placeholderCards = listOf(
    DashboardCard("Notes", "Your saved notes"),
    DashboardCard("Reminders", "Upcoming tasks"),
    DashboardCard("To-Do", "Pending items"),
    DashboardCard("Security", "Owner & intruder log")
)

@Composable
fun HomeScreen(
    onOpenSettings: () -> Unit,
    onOpenSecurity: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nishar", color = NisharGold) },
                actions = {
                    IconButton(onClick = onOpenSecurity) {
                        Icon(Icons.Filled.Security, contentDescription = "Security", tint = NisharGold)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = NisharGold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(placeholderCards) { card -> DashboardCardItem(card) }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                // Tap-to-talk mic. The wake-word slice replaces the manual tap
                // with always-on listening, calling the same onMicTap hook.
                GlowingMicButton(onTap = { /* AI slice: start listening */ })
            }
        }
    }
}

@Composable
private fun DashboardCardItem(card: DashboardCard) {
    Card(
        colors = CardDefaults.cardColors(containerColor = NisharSurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(card.title, color = NisharGold, style = MaterialTheme.typography.titleLarge)
            Text(card.subtitle, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun GlowingMicButton(onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .background(NisharGold.copy(alpha = 0.15f), shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onTap, modifier = Modifier.size(64.dp)) {
            Icon(
                imageVector = Icons.Filled.Mic,
                contentDescription = "Speak to Nishar",
                tint = NisharGold,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
