package com.aditya.nishar.navigation

/**
 * Every navigable destination in the app. Adding a screen in a later slice
 * (e.g. SecurityDashboard, IntruderHistory) means adding one entry here and
 * one composable() block in NisharNavGraph — nothing else touches routing.
 */
sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Home : Screen("home")
    data object Settings : Screen("settings")
    data object Security : Screen("security")
}
