package com.aditya.nishar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.aditya.nishar.navigation.NisharNavGraph
import com.aditya.nishar.ui.theme.NisharTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-Activity architecture: MainActivity only hosts the Compose NavGraph.
 * Every screen is a composable destination — no Fragments, no XML layouts.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NisharTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NisharNavGraph()
                }
            }
        }
    }
}
