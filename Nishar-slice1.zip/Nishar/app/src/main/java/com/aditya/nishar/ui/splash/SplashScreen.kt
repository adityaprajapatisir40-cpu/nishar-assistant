package com.aditya.nishar.ui.splash

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aditya.nishar.ui.theme.NisharBlack
import com.aditya.nishar.ui.theme.NisharGold
import com.aditya.nishar.ui.theme.NisharGoldBright
import kotlinx.coroutines.delay

private const val SPLASH_DURATION_MS = 2200L

/**
 * Full-screen splash: a pulsing gold-glow ring behind a mic icon, with the
 * "Nishar / By Aditya" wordmark. Purely presentational — auto-advances to
 * Home after [SPLASH_DURATION_MS]. Wake-word service startup will be hooked
 * into onFinished() once the AI slice lands, not here.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_glow")
    val glowRadius by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_radius"
    )

    LaunchedEffect(Unit) {
        delay(SPLASH_DURATION_MS)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NisharBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
                Canvas(modifier = Modifier.size(160.dp)) {
                    val radius = size.minDimension / 2 * glowRadius
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(NisharGoldBright.copy(alpha = 0.35f), Color.Transparent),
                            center = Offset(size.width / 2, size.height / 2),
                            radius = radius
                        )
                    )
                }
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .background(NisharGold.copy(alpha = 0.12f), shape = androidx.compose.foundation.shape.CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Mic,
                        contentDescription = null,
                        tint = NisharGold,
                        modifier = Modifier
                            .size(88.dp)
                            .background(Color.Transparent)
                    )
                }
            }

            Text(
                text = "NISHAR",
                color = NisharGold,
                fontSize = 34.sp,
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(top = 24.dp)
            )
            Text(
                text = "By Aditya",
                color = NisharGold.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}
