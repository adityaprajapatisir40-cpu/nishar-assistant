package com.aditya.nishar.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Nishar is a black+gold luxury assistant by design, so the dark palette
// IS the brand identity — not just a system dark-mode fallback.
private val NisharDarkScheme = darkColorScheme(
    primary = NisharGold,
    onPrimary = NisharBlack,
    secondary = NisharGoldDim,
    background = NisharBlack,
    onBackground = NisharTextPrimary,
    surface = NisharSurface,
    onSurface = NisharTextPrimary,
    surfaceVariant = NisharSurfaceVariant,
    error = NisharError
)

// Light scheme kept for completeness / system "force light" accessibility
// settings, but the app defaults to the dark black+gold identity below.
private val NisharLightScheme = lightColorScheme(
    primary = NisharGoldDim,
    onPrimary = NisharBlack,
    background = Color(0xFFF7F5F0),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun NisharTheme(
    useSystemDarkTheme: Boolean = isSystemInDarkTheme(),
    // Owner can toggle this from Settings to force the light scheme; defaults
    // to true so Nishar always opens in its signature black+gold look.
    forceDark: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (forceDark || useSystemDarkTheme) NisharDarkScheme else NisharLightScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NisharTypography,
        content = content
    )
}
