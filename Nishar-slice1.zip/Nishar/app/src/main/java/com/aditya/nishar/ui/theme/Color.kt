package com.aditya.nishar.ui.theme

import androidx.compose.ui.graphics.Color

// --- Nishar Black + Gold palette ---
val NisharBlack = Color(0xFF0A0A0A)          // primary background, near-true black
val NisharSurface = Color(0xFF161616)        // cards / elevated surfaces
val NisharSurfaceVariant = Color(0xFF232323) // input fields, secondary surfaces

val NisharGold = Color(0xFFD4AF37)           // primary gold accent
val NisharGoldBright = Color(0xFFF4D160)     // glow / highlight state (mic pulse)
val NisharGoldDim = Color(0xFF8A6D1F)        // disabled / subtle gold

val NisharTextPrimary = Color(0xFFF5F5F0)    // off-white for readability on black
val NisharTextSecondary = Color(0xFFB8B8B0)

val NisharError = Color(0xFFCF6679)
val NisharSuccess = Color(0xFF4CAF93)
