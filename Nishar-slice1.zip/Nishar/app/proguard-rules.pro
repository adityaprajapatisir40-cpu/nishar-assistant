# Add project specific ProGuard rules here.
# Rules for Hilt/Room/Retrofit/ML Kit will be added as those features
# reach the release build type in later slices.
